
package model;

import java.util.Date;

public class engenheiros {
    
    private int idEngenheiro;
    private String dsNome;
    private int nrCREA;
    private Date dtAdmissao;

    /**
     * @return the idEngenheiro
     */
    public int getIdEngenheiro() {
        return idEngenheiro;
    }

    /**
     * @param idEngenheiro the idEngenheiro to set
     */
    public void setIdEngenheiro(int idEngenheiro) {
        this.idEngenheiro = idEngenheiro;
    }

    /**
     * @return the dsNome
     */
    public String getDsNome() {
        return dsNome;
    }

    /**
     * @param dsNome the dsNome to set
     */
    public void setDsNome(String dsNome) {
        this.dsNome = dsNome;
    }

    /**
     * @return the nrCREA
     */
    public int getNrCREA() {
        return nrCREA;
    }

    /**
     * @param nrCREA the nrCREA to set
     */
    public void setNrCREA(int nrCREA) {
        this.nrCREA = nrCREA;
    }

    /**
     * @return the dtAdmissao
     */
    public Date getDtAdmissao() {
        return dtAdmissao;
    }

    /**
     * @param dtAdmissao the dtAdmissao to set
     */
    public void setDtAdmissao(Date dtAdmissao) {
        this.dtAdmissao = dtAdmissao;
    }
    
}
